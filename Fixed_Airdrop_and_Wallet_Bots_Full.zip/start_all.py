import subprocess

subprocess.Popen(["python", "airdrop_bot.py"])
subprocess.Popen(["python", "wallet_bot.py"])
