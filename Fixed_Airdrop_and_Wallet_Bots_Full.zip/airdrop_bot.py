import asyncio, logging, time, aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from config import *

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

main_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="💰 Balance"), KeyboardButton(text="👥 Referral")],
        [KeyboardButton(text="🎁 Daily"), KeyboardButton(text="💸 Withdraw")],
        [KeyboardButton(text="ℹ️ Help")]
    ],
    resize_keyboard=True
)

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            balance REAL DEFAULT 0,
            last_bonus INTEGER DEFAULT 0,
            referrals INTEGER DEFAULT 0
        )''')
        await db.commit()

@dp.message(CommandStart())
async def start_cmd(message: types.Message):
    user_id = message.from_user.id
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        user = await cursor.fetchone()
        if not user:
            await db.execute("INSERT INTO users (user_id, balance) VALUES (?, ?)", (user_id, JOIN_BONUS))
            await db.commit()
            await message.answer("🎉 Welcome! You received 1 TON as joining bonus.", reply_markup=main_keyboard)
        else:
            await message.answer("👋 Welcome back!", reply_markup=main_keyboard)

@dp.message()
async def buttons(message: types.Message):
    text = message.text.lower()
    user_id = message.from_user.id

    if "balance" in text:
        async with aiosqlite.connect(DB_PATH) as db:
            cur = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
            user = await cur.fetchone()
            if user:
                await message.answer(f"💰 Your balance: {user[0]} TON", reply_markup=main_keyboard)
            else:
                await message.answer("❌ Send /start to join.", reply_markup=main_keyboard)

    elif "referral" in text:
        bot_user = (await bot.me()).username
        link = f"https://t.me/{bot_user}?start={user_id}"
        await message.answer(f"👥 Referral link:\n{link}", reply_markup=main_keyboard)

    elif "daily" in text:
        now = int(time.time())
        async with aiosqlite.connect(DB_PATH) as db:
            cur = await db.execute("SELECT balance, last_bonus FROM users WHERE user_id = ?", (user_id,))
            u = await cur.fetchone()
            if not u:
                return await message.answer("❌ Send /start first.", reply_markup=main_keyboard)
            if now - u[1] >= 86400:
                await db.execute("UPDATE users SET balance = balance + ?, last_bonus = ? WHERE user_id = ?", (DAILY_BONUS, now, user_id))
                await db.commit()
                await message.answer(f"🎁 You claimed {DAILY_BONUS} TON!", reply_markup=main_keyboard)
            else:
                rem = 86400 - (now - u[1])
                await message.answer(f"⏳ Next bonus in {rem//3600}h {(rem%3600)//60}m.", reply_markup=main_keyboard)

    elif "withdraw" in text:
        await message.answer("Send your TON wallet address and amount to withdraw.", reply_markup=main_keyboard)

    elif "help" in text:
        await message.answer("Having issues?\nContact admin.\nState your problem and I will assist.", reply_markup=main_keyboard)

async def main():
    await init_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
