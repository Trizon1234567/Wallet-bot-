import asyncio
import logging
import time
import aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

BOT_TOKEN = "8015314351:AAFWOfM3zjzoi4h1LVjHVmwGo289dIZwFH0"
DB_PATH = "users.db"

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

main_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="💰 Balance"), KeyboardButton(text="💸 Withdraw")]
    ],
    resize_keyboard=True
)

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            balance REAL DEFAULT 0
        )''')
        await db.commit()

@dp.message(CommandStart())
async def start_cmd(message: types.Message):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO users (user_id, balance) VALUES (?, ?)", (message.from_user.id, 10))
        await db.commit()
    await message.answer("Welcome! You have 10 TON.", reply_markup=main_keyboard)

@dp.message()
async def handle_msg(message: types.Message):
    if message.text == "💰 Balance":
        async with aiosqlite.connect(DB_PATH) as db:
            cur = await db.execute("SELECT balance FROM users WHERE user_id = ?", (message.from_user.id,))
            bal = await cur.fetchone()
            await message.answer(f"Your balance: {bal[0]:.2f} TON")
    elif message.text == "💸 Withdraw":
        async with aiosqlite.connect(DB_PATH) as db:
            cur = await db.execute("SELECT balance FROM users WHERE user_id = ?", (message.from_user.id,))
            bal = await cur.fetchone()
            if bal and bal[0] > 0:
                await db.execute("UPDATE users SET balance = 0 WHERE user_id = ?", (message.from_user.id,))
                await db.commit()
                await message.answer("Withdrawal successful! Click to continue: https://t.me/YourWalletBot")
            else:
                await message.answer("No funds available.")

async def main():
    await init_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
