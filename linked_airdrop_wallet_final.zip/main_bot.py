import asyncio
import logging
import aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart
from config import *

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

async def init_db():
    async with aiosqlite.connect("users.db") as db:
        await db.execute(
            "CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, balance REAL DEFAULT 0, deposited REAL DEFAULT 0)"
        )
        await db.commit()

@dp.message(CommandStart())
async def start_cmd(message: types.Message):
    user_id = message.from_user.id
    async with aiosqlite.connect("users.db") as db:
        cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        user = await cursor.fetchone()
        if not user:
            await db.execute("INSERT INTO users (user_id, balance, deposited) VALUES (?, ?, 0)", (user_id, JOIN_BONUS))
            await db.commit()
            await message.answer("🎉 Welcome! You received 1 TON as a joining bonus.")
        else:
            await message.answer("👋 Welcome back! Use /balance to check your TON.")

@dp.message()
async def balance_cmd(message: types.Message):
    if message.text.strip().lower() == "/balance":
        user_id = message.from_user.id
        async with aiosqlite.connect("users.db") as db:
            cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
            user = await cursor.fetchone()
            if user:
                await message.answer(f"💰 Your current balance: <b>{user[0]:.2f} TON</b>", parse_mode=ParseMode.HTML)
            else:
                await message.answer("❌ You're not registered. Send /start to join.")

async def main():
    await init_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
