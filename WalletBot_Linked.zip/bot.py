import asyncio
import logging
import aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

BOT_TOKEN = "7988757416:AAE6ApzjE7WvMRxKp3W5ZpH8rsyrrfv71Yg"
DB_PATH = "users.db"

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

main_keyboard = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="💎 Wallet Balance")]],
    resize_keyboard=True
)

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            balance REAL DEFAULT 0
        )''')
        await db.commit()

@dp.message()
async def handle_msg(message: types.Message):
    if message.text == "💎 Wallet Balance":
        async with aiosqlite.connect(DB_PATH) as db:
            cur = await db.execute("SELECT balance FROM users WHERE user_id = ?", (message.from_user.id,))
            bal = await cur.fetchone()
            await message.answer(f"Wallet balance: {bal[0]:.2f} TON")

async def main():
    await init_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
