import subprocess

processes = []

try:
    p1 = subprocess.Popen(["python", "main_bot.py"])
    processes.append(p1)

    p2 = subprocess.Popen(["python", "wallet_bot.py"])
    processes.append(p2)

    print("Both bots are now running... Press Ctrl+C to stop.")
    for p in processes:
        p.wait()

except KeyboardInterrupt:
    print("Stopping all bots...")
    for p in processes:
        p.terminate()
