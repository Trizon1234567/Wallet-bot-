import asyncio
import logging
import aiohttp
import aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

BOT_TOKEN = "7988757416:AAE6ApzjE7WvMRxKp3W5ZpH8rsyrrfv71Yg"
ADMIN_ID = 7988595664
TON_DEPOSIT_ADDRESS = "UQDbWG-rt9WPhx_lWhlUYSezvBcXDvGiyagj72rnTGocUHwj"
MIN_WITHDRAW_TON = 5
DB_PATH = "users.db"  # Path to main bot's database

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

coin_info = {
    "TON": {"emoji": "💎", "image": "https://cryptologos.cc/logos/toncoin-ton-logo.png", "id": "the-open-network", "deposit": TON_DEPOSIT_ADDRESS},
    "BTC": {"emoji": "₿", "image": "https://cryptologos.cc/logos/bitcoin-btc-logo.png", "id": "bitcoin", "deposit": "Your-BTC-Wallet-Address"},
    "ETH": {"emoji": "Ξ", "image": "https://cryptologos.cc/logos/ethereum-eth-logo.png", "id": "ethereum", "deposit": "Your-ETH-Wallet-Address"},
    "USDT": {"emoji": "💵", "image": "https://cryptologos.cc/logos/tether-usdt-logo.png", "id": "tether", "deposit": "Your-USDT-Wallet-Address"}
}

main_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="💎 TON"), KeyboardButton(text="₿ BTC")],
        [KeyboardButton(text="Ξ ETH"), KeyboardButton(text="💵 USDT")],
        [KeyboardButton(text="📊 Overview")]
    ],
    resize_keyboard=True
)

async def get_prices():
    ids = ",".join([coin_info[c]["id"] for c in coin_info])
    url = f"https://api.coingecko.com/api/v3/simple/price?ids={ids}&vs_currencies=usd"
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            return await resp.json()

async def get_user_balance(user_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, balance REAL DEFAULT 0)""")
        cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        result = await cursor.fetchone()
        if result:
            return result[0]
        else:
            await db.execute("INSERT INTO users (user_id, balance) VALUES (?, 0)", (user_id,))
            await db.commit()
            return 0.0

async def update_user_balance(user_id, new_balance):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET balance = ? WHERE user_id = ?", (new_balance, user_id))
        await db.commit()

async def auto_update_overview(chat_id, message_id, user_id):
    for _ in range(30):
        data = await get_prices()
        overview_text = "<b>📊 Portfolio Overview (Live)</b>\n\n"
        total_usd = 0
        ton_balance = await get_user_balance(user_id)
        for coin in coin_info:
            balance = ton_balance if coin == "TON" else 0.0
            price = data.get(coin_info[coin]["id"], {}).get("usd", 0)
            usd_value = balance * price
            total_usd += usd_value
            overview_text += f"{coin_info[coin]['emoji']} {coin}: {balance:.4f} ({usd_value:.2f} USD)\n"
        overview_text += f"\n<b>Total Value: ${total_usd:.2f}</b>"
        try:
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=overview_text, parse_mode=ParseMode.HTML)
        except:
            break
        await asyncio.sleep(10)

@dp.message()
async def handle_message(message: types.Message):
    text = message.text.strip()
    user_id = message.from_user.id

    if text == "📊 Overview":
        msg = await message.answer("⏳ Loading live portfolio...", reply_markup=main_keyboard)
        await auto_update_overview(message.chat.id, msg.message_id, user_id)
        return

    stripped_text = text.replace("💎","").replace("₿","").replace("Ξ","").replace("💵","").strip().upper()
    if stripped_text in coin_info:
        data = await get_prices()
        balance = await get_user_balance(user_id) if stripped_text == "TON" else 0.0
        price = data.get(coin_info[stripped_text]["id"], {}).get("usd", 0)
        usd_value = balance * price
        caption = f"{coin_info[stripped_text]['emoji']} <b>{stripped_text} Wallet</b>\nBalance: {balance:.4f} {stripped_text}\nMarket Value: ${usd_value:.2f}"
        coin_keyboard = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Deposit"), KeyboardButton(text="Withdraw")],[KeyboardButton(text="Back")]],
            resize_keyboard=True
        )
        await bot.send_photo(message.chat.id, coin_info[stripped_text]["image"], caption=caption, reply_markup=coin_keyboard)

    elif text.lower() == "deposit":
        await message.answer(f"Deposit TON to:\n<code>{TON_DEPOSIT_ADDRESS}</code>\n\nFor BTC, ETH, USDT, use your respective addresses.", parse_mode=ParseMode.HTML)
    elif text.lower() == "withdraw":
        ton_balance = await get_user_balance(user_id)
        if ton_balance >= MIN_WITHDRAW_TON:
            new_balance = ton_balance - MIN_WITHDRAW_TON
            await update_user_balance(user_id, new_balance)
            await message.answer("✅ Successful withdrawal! Confirm in 24 hours.")
            await bot.send_message(ADMIN_ID, f"User {user_id} withdrew {MIN_WITHDRAW_TON} TON. New balance: {new_balance:.4f} TON.")
        else:
            await message.answer(f"❌ You must have at least {MIN_WITHDRAW_TON} TON before withdrawal. Your balance: {ton_balance:.4f} TON.")
    elif text.lower() == "back":
        await message.answer("Choose a coin:", reply_markup=main_keyboard)
    else:
        await message.answer("Use the menu buttons.", reply_markup=main_keyboard)

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
