import asyncio
import logging
import aiohttp
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

BOT_TOKEN = "7988757416:AAE6ApzjE7WvMRxKp3W5ZpH8rsyrrfv71Yg"
ADMIN_ID = 7988595664
TON_DEPOSIT_ADDRESS = "UQDbWG-rt9WPhx_lWhlUYSezvBcXDvGiyagj72rnTGocUHwj"
MIN_WITHDRAW_TON = 5

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

user_balances = {
    "TON": 18.2,
    "BTC": 0.0,
    "ETH": 0.0,
    "USDT": 0.0
}

coin_info = {
    "TON": {"emoji": "💎", "image": "https://cryptologos.cc/logos/toncoin-ton-logo.png", "id": "the-open-network"},
    "BTC": {"emoji": "₿", "image": "https://cryptologos.cc/logos/bitcoin-btc-logo.png", "id": "bitcoin"},
    "ETH": {"emoji": "Ξ", "image": "https://cryptologos.cc/logos/ethereum-eth-logo.png", "id": "ethereum"},
    "USDT": {"emoji": "💵", "image": "https://cryptologos.cc/logos/tether-usdt-logo.png", "id": "tether"}
}

main_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="💎 TON"), KeyboardButton(text="₿ BTC")],
        [KeyboardButton(text="Ξ ETH"), KeyboardButton(text="💵 USDT")],
        [KeyboardButton(text="📊 Overview")]
    ],
    resize_keyboard=True
)

async def get_prices():
    ids = ",".join([coin_info[c]["id"] for c in coin_info])
    url = f"https://api.coingecko.com/api/v3/simple/price?ids={ids}&vs_currencies=usd"
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            return await resp.json()

async def auto_update_overview(chat_id, message_id):
    for _ in range(30):  # run for ~5 minutes (30 x 10s)
        data = await get_prices()
        overview_text = "<b>📊 Portfolio Overview (Live)</b>\n\n"
        total_usd = 0
        for coin, balance in user_balances.items():
            price = data.get(coin_info[coin]["id"], {}).get("usd", 0)
            usd_value = balance * price
            total_usd += usd_value
            overview_text += f"{coin_info[coin]['emoji']} {coin}: {balance} ({usd_value:.2f} USD)\n"
        overview_text += f"\n<b>Total Value: ${total_usd:.2f}</b>"
        try:
            await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=overview_text, parse_mode=ParseMode.HTML)
        except:
            break  # Stop updating if message is deleted or changed
        await asyncio.sleep(10)

@dp.message()
async def handle_message(message: types.Message):
    text = message.text.strip()

    if text == "📊 Overview":
        msg = await message.answer("⏳ Loading live portfolio...", reply_markup=main_keyboard)
        await auto_update_overview(message.chat.id, msg.message_id)
        return

    stripped_text = text.replace("💎","").replace("₿","").replace("Ξ","").replace("💵","").strip().upper()
    if stripped_text in user_balances:
        async with aiohttp.ClientSession() as session:
            resp = await session.get(f"https://api.coingecko.com/api/v3/simple/price?ids={coin_info[stripped_text]['id']}&vs_currencies=usd")
            price = (await resp.json()).get(coin_info[stripped_text]["id"], {}).get("usd", 0)
        balance = user_balances[stripped_text]
        usd_value = balance * price
        caption = f"{coin_info[stripped_text]['emoji']} <b>{stripped_text} Wallet</b>\nBalance: {balance} {stripped_text}\nMarket Value: ${usd_value:.2f}"
        coin_keyboard = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Deposit"), KeyboardButton(text="Withdraw")],[KeyboardButton(text="Back")]],
            resize_keyboard=True
        )
        await bot.send_photo(message.chat.id, coin_info[stripped_text]["image"], caption=caption, reply_markup=coin_keyboard)

    elif text.lower() == "deposit":
        await message.answer(f"Deposit TON to:\n<code>{TON_DEPOSIT_ADDRESS}</code>", parse_mode=ParseMode.HTML)
    elif text.lower() == "withdraw":
        ton_balance = user_balances["TON"]
        if ton_balance >= MIN_WITHDRAW_TON:
            await message.answer("✅ Withdrawal request sent to admin.")
            await bot.send_message(ADMIN_ID, f"User {message.from_user.id} requested withdrawal of {ton_balance} TON.")
        else:
            await message.answer(f"❌ You need at least {MIN_WITHDRAW_TON} TON. Your balance: {ton_balance} TON.")
    elif text.lower() == "back":
        await message.answer("Choose a coin:", reply_markup=main_keyboard)
    else:
        await message.answer("Use the menu buttons.", reply_markup=main_keyboard)

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
